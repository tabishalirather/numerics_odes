import numpy as np
from scipy.integrate import odeint

def zombie(strategy,pa,pb):
    """
    zombie(strategy,pa,pb)
    
    This function computes the evolution of the populations of humans and zombies 
    according to a chosen mitigation strategy.
    
    Parameters
    -----------------
    strategy : integer
        mitigation strategy
        0 : no intervention
        1 : training and arming humans
        2 : vaccination of humans 
    pa : real number
        uncertainty in the paramater alpha (= efficiency of humans killing zombies)
    pb : real number
        uncertainty in the paramater beta (= efficiency of zombies infecting humans)

    Returns
    -----------------
    t : numpy.array
        vector containing the time grid of the integration period of 1 year, t = [0,...,1]
    x : numpy.array 
        x[i,0] : number of humans at time t[i]      
        x[i,1] : number of zombies at time t[i]      
        x[i,2] : number of removed zombies at time t[i]      
    
    Example
    -----------------
    >>> t, x = zombie(0,0,0)        # Baseline scenario without intervention and with given values of alpha and beta  
    >>> t, x = zombie(1,-0.25,0.25) # Strategy 1 in worst case scenario where alpha is 25% decreased and beta is 25% increased.  
    """
    
    ####################
    #edit the code here#
    ####################
    
    return ##
